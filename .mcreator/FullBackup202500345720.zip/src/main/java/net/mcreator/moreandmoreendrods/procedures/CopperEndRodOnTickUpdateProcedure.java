package net.mcreator.moreandmoreendrods.procedures;

import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.tags.TagKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.BlockPos;

import net.mcreator.moreandmoreendrods.init.MoreandmoreendrodsModBlocks;

public class CopperEndRodOnTickUpdateProcedure {
	public static boolean eventResult = true;

	public static void execute(LevelAccessor world, double x, double y, double z) {
		if (!(world.getBlockState(BlockPos.containing(x, y, z))).is(TagKey.create(Registries.BLOCK, ResourceLocation.parse("minecraft:waxed_copper_end_rod")))) {
			if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == MoreandmoreendrodsModBlocks.COPPER_END_ROD) {
				{
					BlockPos _bp4 = BlockPos.containing(x, y, z);
					BlockState _bs4 = MoreandmoreendrodsModBlocks.EXPOSED_COPPER_END_ROD.defaultBlockState();
					BlockState _bso = world.getBlockState(_bp4);
					for (Property<?> _propertyOld : _bso.getProperties()) {
						Property _propertyNew = _bs4.getBlock().getStateDefinition().getProperty(_propertyOld.getName());
						if (_propertyNew != null && _bs4.getValue(_propertyNew) != null)
							try {
								_bs4 = _bs4.setValue(_propertyNew, _bso.getValue(_propertyOld));
							} catch (Exception e) {
							}
					}
					world.setBlock(_bp4, _bs4, 3);
				}
			} else if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == MoreandmoreendrodsModBlocks.EXPOSED_COPPER_END_ROD) {
				{
					BlockPos _bp7 = BlockPos.containing(x, y, z);
					BlockState _bs7 = MoreandmoreendrodsModBlocks.WEATHERED_COPPER_END_ROD.defaultBlockState();
					BlockState _bso = world.getBlockState(_bp7);
					for (Property<?> _propertyOld : _bso.getProperties()) {
						Property _propertyNew = _bs7.getBlock().getStateDefinition().getProperty(_propertyOld.getName());
						if (_propertyNew != null && _bs7.getValue(_propertyNew) != null)
							try {
								_bs7 = _bs7.setValue(_propertyNew, _bso.getValue(_propertyOld));
							} catch (Exception e) {
							}
					}
					world.setBlock(_bp7, _bs7, 3);
				}
			} else if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == MoreandmoreendrodsModBlocks.WEATHERED_COPPER_END_ROD) {
				{
					BlockPos _bp10 = BlockPos.containing(x, y, z);
					BlockState _bs10 = MoreandmoreendrodsModBlocks.OXIDIZED_COPPER_END_ROD.defaultBlockState();
					BlockState _bso = world.getBlockState(_bp10);
					for (Property<?> _propertyOld : _bso.getProperties()) {
						Property _propertyNew = _bs10.getBlock().getStateDefinition().getProperty(_propertyOld.getName());
						if (_propertyNew != null && _bs10.getValue(_propertyNew) != null)
							try {
								_bs10 = _bs10.setValue(_propertyNew, _bso.getValue(_propertyOld));
							} catch (Exception e) {
							}
					}
					world.setBlock(_bp10, _bs10, 3);
				}
			}
		}
	}
}