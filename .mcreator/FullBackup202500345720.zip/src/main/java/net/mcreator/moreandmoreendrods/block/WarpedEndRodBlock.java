package net.mcreator.moreandmoreendrods.block;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.EndRodBlock;
import net.minecraft.client.renderer.chunk.ChunkSectionLayer;

import net.mcreator.moreandmoreendrods.init.MoreandmoreendrodsModBlocks;

import net.fabricmc.fabric.api.client.rendering.v1.BlockRenderLayerMap;
import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvType;

public class WarpedEndRodBlock extends EndRodBlock {
	public WarpedEndRodBlock(BlockBehaviour.Properties properties) {
		super(properties.sound(SoundType.GRAVEL).strength(1f, 10f).noOcclusion().isRedstoneConductor((bs, br, bp) -> false).forceSolidOff());
	}

	@Environment(EnvType.CLIENT)
	public static void registerRenderLayer() {
		BlockRenderLayerMap.putBlock(MoreandmoreendrodsModBlocks.WARPED_END_ROD, ChunkSectionLayer.CUTOUT);
	}

	@Override
	public int getLightBlock(BlockState state) {
		return 0;
	}
}