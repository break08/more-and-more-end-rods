package net.mcreator.moreandmoreendrods.procedures;

import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.BlockPos;
import net.minecraft.advancements.AdvancementProgress;
import net.minecraft.advancements.AdvancementHolder;

import net.mcreator.moreandmoreendrods.init.MoreandmoreendrodsModBlocks;

public class CopperEndRodOnBlockRightclickedProcedure {
	public static boolean eventResult = true;

	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if ((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.HONEYCOMB) {
			if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == MoreandmoreendrodsModBlocks.COPPER_END_ROD) {
				{
					BlockPos _bp4 = BlockPos.containing(x, y, z);
					BlockState _bs4 = MoreandmoreendrodsModBlocks.WAXED_COPPER_END_ROD.defaultBlockState();
					BlockState _bso = world.getBlockState(_bp4);
					for (Property<?> _propertyOld : _bso.getProperties()) {
						Property _propertyNew = _bs4.getBlock().getStateDefinition().getProperty(_propertyOld.getName());
						if (_propertyNew != null && _bs4.getValue(_propertyNew) != null)
							try {
								_bs4 = _bs4.setValue(_propertyNew, _bso.getValue(_propertyOld));
							} catch (Exception e) {
							}
					}
					world.setBlock(_bp4, _bs4, 3);
				}
			} else if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == MoreandmoreendrodsModBlocks.EXPOSED_COPPER_END_ROD) {
				{
					BlockPos _bp7 = BlockPos.containing(x, y, z);
					BlockState _bs7 = MoreandmoreendrodsModBlocks.WAXED_EXPOSED_COPPER_END_ROD.defaultBlockState();
					BlockState _bso = world.getBlockState(_bp7);
					for (Property<?> _propertyOld : _bso.getProperties()) {
						Property _propertyNew = _bs7.getBlock().getStateDefinition().getProperty(_propertyOld.getName());
						if (_propertyNew != null && _bs7.getValue(_propertyNew) != null)
							try {
								_bs7 = _bs7.setValue(_propertyNew, _bso.getValue(_propertyOld));
							} catch (Exception e) {
							}
					}
					world.setBlock(_bp7, _bs7, 3);
				}
			} else if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == MoreandmoreendrodsModBlocks.WEATHERED_COPPER_END_ROD) {
				{
					BlockPos _bp10 = BlockPos.containing(x, y, z);
					BlockState _bs10 = MoreandmoreendrodsModBlocks.WAXED_WEATHERED_COPPER_END_ROD.defaultBlockState();
					BlockState _bso = world.getBlockState(_bp10);
					for (Property<?> _propertyOld : _bso.getProperties()) {
						Property _propertyNew = _bs10.getBlock().getStateDefinition().getProperty(_propertyOld.getName());
						if (_propertyNew != null && _bs10.getValue(_propertyNew) != null)
							try {
								_bs10 = _bs10.setValue(_propertyNew, _bso.getValue(_propertyOld));
							} catch (Exception e) {
							}
					}
					world.setBlock(_bp10, _bs10, 3);
				}
			}
			if (entity instanceof ServerPlayer _player && _player.level() instanceof ServerLevel _level) {
				AdvancementHolder _adv11 = _level.getServer().getAdvancements().get(ResourceLocation.parse("minecraft:husbandry/wax_on"));
				if (_adv11 != null) {
					AdvancementProgress _ap = _player.getAdvancements().getOrStartProgress(_adv11);
					if (!_ap.isDone()) {
						for (String criteria : _ap.getRemainingCriteria())
							_player.getAdvancements().award(_adv11, criteria);
					}
				}
			}
		}
	}
}