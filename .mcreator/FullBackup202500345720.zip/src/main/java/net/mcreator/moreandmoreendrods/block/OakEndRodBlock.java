package net.mcreator.moreandmoreendrods.block;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.EndRodBlock;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.client.renderer.chunk.ChunkSectionLayer;

import net.mcreator.moreandmoreendrods.init.MoreandmoreendrodsModBlocks;

import net.fabricmc.fabric.api.registry.FlammableBlockRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.BlockRenderLayerMap;
import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvType;

public class OakEndRodBlock extends EndRodBlock {
	public OakEndRodBlock(BlockBehaviour.Properties properties) {
		super(properties.sound(new SoundType(1.0f, 1.0f, null, null, null, null, null) {
			@Override
			public SoundEvent getBreakSound() {
				return BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("block.wood.break"));
			}

			@Override
			public SoundEvent getStepSound() {
				return BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("block.wood.step"));
			}

			@Override
			public SoundEvent getPlaceSound() {
				return BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("block.wood.place"));
			}

			@Override
			public SoundEvent getHitSound() {
				return BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("block.wood.hit"));
			}

			@Override
			public SoundEvent getFallSound() {
				return BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("block.wood.fall"));
			}
		}).strength(1f, 10f).ignitedByLava().forceSolidOff());
		FlammableBlockRegistry.getDefaultInstance().add(this, 15, 160);
	}

	@Environment(EnvType.CLIENT)
	public static void registerRenderLayer() {
		BlockRenderLayerMap.putBlock(MoreandmoreendrodsModBlocks.OAK_END_ROD, ChunkSectionLayer.CUTOUT);
	}

	@Override
	public int getLightBlock(BlockState state) {
		return 0;
	}
}