/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.moreandmoreendrods.init;

import net.mcreator.moreandmoreendrods.block.*;

import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvType;

@Environment(EnvType.CLIENT)
public class MoreandmoreendrodsModBlocksRenderers {
	public static void clientLoad() {
		OakEndRodBlock.registerRenderLayer();
		CherryEndRodBlock.registerRenderLayer();
		BirchEndRodBlock.registerRenderLayer();
		SpruceEndRodBlock.registerRenderLayer();
		StoneEndRodBlock.registerRenderLayer();
		IronEndRodBlock.registerRenderLayer();
		CopperEndRodBlock.registerRenderLayer();
		GlowstoneEndRodBlock.registerRenderLayer();
		EmeraldEndRodBlock.registerRenderLayer();
		DiamondEndRodBlock.registerRenderLayer();
		NetheriteEndRodBlock.registerRenderLayer();
		CrimsonEndRodBlock.registerRenderLayer();
		WarpedEndRodBlock.registerRenderLayer();
		ExposedCopperEndRodBlock.registerRenderLayer();
		WeatheredCopperEndRodBlock.registerRenderLayer();
		OxidizedCopperEndRodBlock.registerRenderLayer();
		WaxedCopperEndRodBlock.registerRenderLayer();
		WaxedExposedCopperEndRodBlock.registerRenderLayer();
		WaxedWeatheredCopperEndRodBlock.registerRenderLayer();
		JungleEndRodBlock.registerRenderLayer();
		AcaciaEndRodBlock.registerRenderLayer();
		DarkOakEndRodBlock.registerRenderLayer();
		MangroveEndRodBlock.registerRenderLayer();
		PrismarineEndRodBlock.registerRenderLayer();
		GoldenEndRodBlock.registerRenderLayer();
		ShulkerEndRodBlock.registerRenderLayer();
		PinkEndRodBlock.registerRenderLayer();
		BlueEndRodBlock.registerRenderLayer();
		LightBlueEndRodBlock.registerRenderLayer();
		PurpleEndRodBlock.registerRenderLayer();
		YellowEndRodBlock.registerRenderLayer();
		GrayEndRodBlock.registerRenderLayer();
		LightGrayEndRodBlock.registerRenderLayer();
		BlackEndRodBlock.registerRenderLayer();
		OrangeEndRodBlock.registerRenderLayer();
		RedEndRodBlock.registerRenderLayer();
		CyanEndRodBlock.registerRenderLayer();
		GreenEndRodBlock.registerRenderLayer();
		LimeEndRodBlock.registerRenderLayer();
		AmethystEndRodBlock.registerRenderLayer();
		BrickEndRodBlock.registerRenderLayer();
		NetherBrickEndRodBlock.registerRenderLayer();
		MagentaEndRodBlock.registerRenderLayer();
		StoneBrickEndRodBlock.registerRenderLayer();
		LongEndRodBlock.registerRenderLayer();
		CactusEndRodBlock.registerRenderLayer();
	}
	// Start of user code block custom block renderers
	// End of user code block custom block renderers
}