/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package com.mojang.realmsclient.dto;

import com.google.gson.annotations.SerializedName;
import com.mojang.realmsclient.dto.RealmsDescriptionDto;
import com.mojang.realmsclient.dto.RealmsSetting;
import com.mojang.realmsclient.dto.RealmsSlotUpdateDto;
import com.mojang.realmsclient.dto.ReflectionBasedSerialization;
import com.mojang.realmsclient.dto.RegionSelectionPreferenceDto;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.jspecify.annotations.Nullable;

@Environment(value=EnvType.CLIENT)
public record RealmsConfigurationDto(@SerializedName(value="options") RealmsSlotUpdateDto options, @SerializedName(value="settings") List<RealmsSetting> settings, @SerializedName(value="regionSelectionPreference") @Nullable RegionSelectionPreferenceDto regionSelectionPreference, @SerializedName(value="description") @Nullable RealmsDescriptionDto description) implements ReflectionBasedSerialization
{
    @SerializedName(value="options")
    public RealmsSlotUpdateDto options() {
        return this.options;
    }

    @SerializedName(value="settings")
    public List<RealmsSetting> settings() {
        return this.settings;
    }

    @SerializedName(value="regionSelectionPreference")
    public @Nullable RegionSelectionPreferenceDto regionSelectionPreference() {
        return this.regionSelectionPreference;
    }

    @SerializedName(value="description")
    public @Nullable RealmsDescriptionDto description() {
        return this.description;
    }
}

