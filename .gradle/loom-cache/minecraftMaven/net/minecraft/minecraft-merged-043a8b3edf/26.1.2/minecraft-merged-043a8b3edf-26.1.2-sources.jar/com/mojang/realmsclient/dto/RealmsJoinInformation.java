/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package com.mojang.realmsclient.dto;

import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.mojang.logging.LogUtils;
import com.mojang.realmsclient.dto.GuardedSerializer;
import com.mojang.realmsclient.dto.RealmsRegion;
import com.mojang.realmsclient.dto.ReflectionBasedSerialization;
import com.mojang.realmsclient.dto.ServiceQuality;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.jspecify.annotations.Nullable;
import org.slf4j.Logger;

@Environment(value=EnvType.CLIENT)
public record RealmsJoinInformation(@SerializedName(value="address") @Nullable String address, @SerializedName(value="resourcePackUrl") @Nullable String resourcePackUrl, @SerializedName(value="resourcePackHash") @Nullable String resourcePackHash, @SerializedName(value="sessionRegionData") @Nullable RegionData regionData) implements ReflectionBasedSerialization
{
    private static final Logger LOGGER = LogUtils.getLogger();
    private static final RealmsJoinInformation EMPTY = new RealmsJoinInformation(null, null, null, null);

    public static RealmsJoinInformation parse(GuardedSerializer gson, String json) {
        try {
            RealmsJoinInformation server = gson.fromJson(json, RealmsJoinInformation.class);
            if (server == null) {
                LOGGER.error("Could not parse RealmsServerAddress: {}", (Object)json);
                return EMPTY;
            }
            return server;
        } catch (Exception e) {
            LOGGER.error("Could not parse RealmsServerAddress", e);
            return EMPTY;
        }
    }

    @SerializedName(value="address")
    public @Nullable String address() {
        return this.address;
    }

    @SerializedName(value="resourcePackUrl")
    public @Nullable String resourcePackUrl() {
        return this.resourcePackUrl;
    }

    @SerializedName(value="resourcePackHash")
    public @Nullable String resourcePackHash() {
        return this.resourcePackHash;
    }

    @SerializedName(value="sessionRegionData")
    public @Nullable RegionData regionData() {
        return this.regionData;
    }

    @Environment(value=EnvType.CLIENT)
    public record RegionData(@SerializedName(value="regionName") @JsonAdapter(value=RealmsRegion.RealmsRegionJsonAdapter.class) @Nullable RealmsRegion region, @SerializedName(value="serviceQuality") @JsonAdapter(value=ServiceQuality.RealmsServiceQualityJsonAdapter.class) @Nullable ServiceQuality serviceQuality) implements ReflectionBasedSerialization
    {
        @SerializedName(value="regionName")
        public @Nullable RealmsRegion region() {
            return this.region;
        }

        @SerializedName(value="serviceQuality")
        public @Nullable ServiceQuality serviceQuality() {
            return this.serviceQuality;
        }
    }
}

