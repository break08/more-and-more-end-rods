/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package com.mojang.realmsclient.dto;

import com.google.gson.annotations.SerializedName;
import com.mojang.realmsclient.dto.RealmsServer;
import com.mojang.realmsclient.dto.RealmsWorldOptions;
import com.mojang.realmsclient.dto.ReflectionBasedSerialization;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.jspecify.annotations.Nullable;

@Environment(value=EnvType.CLIENT)
public record RealmsSlotUpdateDto(@SerializedName(value="slotId") int slotId, @SerializedName(value="spawnProtection") int spawnProtection, @SerializedName(value="forceGameMode") boolean forceGameMode, @SerializedName(value="difficulty") int difficulty, @SerializedName(value="gameMode") int gameMode, @SerializedName(value="slotName") String slotName, @SerializedName(value="version") String version, @SerializedName(value="compatibility") RealmsServer.Compatibility compatibility, @SerializedName(value="worldTemplateId") long templateId, @SerializedName(value="worldTemplateImage") @Nullable String templateImage, @SerializedName(value="hardcore") boolean hardcore) implements ReflectionBasedSerialization
{
    public RealmsSlotUpdateDto(int slotId, RealmsWorldOptions options, boolean hardcore) {
        this(slotId, options.spawnProtection, options.forceGameMode, options.difficulty, options.gameMode, options.getSlotName(slotId), options.version, options.compatibility, options.templateId, options.templateImage, hardcore);
    }

    @SerializedName(value="slotId")
    public int slotId() {
        return this.slotId;
    }

    @SerializedName(value="spawnProtection")
    public int spawnProtection() {
        return this.spawnProtection;
    }

    @SerializedName(value="forceGameMode")
    public boolean forceGameMode() {
        return this.forceGameMode;
    }

    @SerializedName(value="difficulty")
    public int difficulty() {
        return this.difficulty;
    }

    @SerializedName(value="gameMode")
    public int gameMode() {
        return this.gameMode;
    }

    @SerializedName(value="slotName")
    public String slotName() {
        return this.slotName;
    }

    @SerializedName(value="version")
    public String version() {
        return this.version;
    }

    @SerializedName(value="compatibility")
    public RealmsServer.Compatibility compatibility() {
        return this.compatibility;
    }

    @SerializedName(value="worldTemplateId")
    public long templateId() {
        return this.templateId;
    }

    @SerializedName(value="worldTemplateImage")
    public @Nullable String templateImage() {
        return this.templateImage;
    }

    @SerializedName(value="hardcore")
    public boolean hardcore() {
        return this.hardcore;
    }
}

