/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package com.mojang.realmsclient.dto;

import com.google.gson.annotations.SerializedName;
import com.mojang.realmsclient.dto.ReflectionBasedSerialization;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public record RealmsSetting(@SerializedName(value="name") String name, @SerializedName(value="value") String value) implements ReflectionBasedSerialization
{
    public static RealmsSetting hardcoreSetting(boolean hardcore) {
        return new RealmsSetting("hardcore", Boolean.toString(hardcore));
    }

    public static boolean isHardcore(List<RealmsSetting> settings) {
        for (RealmsSetting setting : settings) {
            if (!setting.name().equals("hardcore")) continue;
            return Boolean.parseBoolean(setting.value());
        }
        return false;
    }

    @SerializedName(value="name")
    public String name() {
        return this.name;
    }

    @SerializedName(value="value")
    public String value() {
        return this.value;
    }
}

