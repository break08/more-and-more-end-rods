/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package net.minecraft.client.data.models.blockstates;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.renderer.block.dispatch.BlockStateModelDispatcher;
import net.minecraft.world.level.block.Block;

@Environment(value=EnvType.CLIENT)
public interface BlockModelDefinitionGenerator {
    public Block block();

    public BlockStateModelDispatcher create();
}

