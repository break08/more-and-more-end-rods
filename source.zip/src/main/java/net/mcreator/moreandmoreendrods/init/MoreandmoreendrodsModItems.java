/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.moreandmoreendrods.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.moreandmoreendrods.MoreandmoreendrodsMod;

public class MoreandmoreendrodsModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, MoreandmoreendrodsMod.MODID);
	public static final RegistryObject<Item> OAK_END_ROD;
	public static final RegistryObject<Item> CHERRY_END_ROD;
	public static final RegistryObject<Item> BIRCH_END_ROD;
	public static final RegistryObject<Item> SPRUCE_END_ROD;
	public static final RegistryObject<Item> STONE_END_ROD;
	public static final RegistryObject<Item> IRON_END_ROD;
	public static final RegistryObject<Item> COPPER_END_ROD;
	public static final RegistryObject<Item> GLOWSTONE_END_ROD;
	public static final RegistryObject<Item> EMERALD_END_ROD;
	public static final RegistryObject<Item> DIAMOND_END_ROD;
	public static final RegistryObject<Item> NETHERITE_END_ROD;
	public static final RegistryObject<Item> CRIMSON_END_ROD;
	public static final RegistryObject<Item> WARPED_END_ROD;
	public static final RegistryObject<Item> EXPOSED_COPPER_END_ROD;
	public static final RegistryObject<Item> WEATHERED_COPPER_END_ROD;
	public static final RegistryObject<Item> OXIDIZED_COPPER_END_ROD;
	public static final RegistryObject<Item> WAXED_COPPER_END_ROD;
	public static final RegistryObject<Item> WAXED_EXPOSED_COPPER_END_ROD;
	public static final RegistryObject<Item> WAXED_WEATHERED_COPPER_END_ROD;
	public static final RegistryObject<Item> JUNGLE_END_ROD;
	public static final RegistryObject<Item> ACACIA_END_ROD;
	public static final RegistryObject<Item> DARK_OAK_END_ROD;
	public static final RegistryObject<Item> MANGROVE_END_ROD;
	public static final RegistryObject<Item> PRISMARINE_END_ROD;
	public static final RegistryObject<Item> GOLDEN_END_ROD;
	public static final RegistryObject<Item> SHULKER_END_ROD;
	public static final RegistryObject<Item> PINK_END_ROD;
	public static final RegistryObject<Item> BLUE_END_ROD;
	public static final RegistryObject<Item> LIGHT_BLUE_END_ROD;
	public static final RegistryObject<Item> PURPLE_END_ROD;
	public static final RegistryObject<Item> YELLOW_END_ROD;
	public static final RegistryObject<Item> GRAY_END_ROD;
	public static final RegistryObject<Item> LIGHT_GRAY_END_ROD;
	public static final RegistryObject<Item> BLACK_END_ROD;
	public static final RegistryObject<Item> ORANGE_END_ROD;
	public static final RegistryObject<Item> RED_END_ROD;
	public static final RegistryObject<Item> CYAN_END_ROD;
	public static final RegistryObject<Item> GREEN_END_ROD;
	public static final RegistryObject<Item> LIME_END_ROD;
	public static final RegistryObject<Item> AMETHYST_END_ROD;
	public static final RegistryObject<Item> BRICK_END_ROD;
	public static final RegistryObject<Item> NETHER_BRICK_END_ROD;
	public static final RegistryObject<Item> MAGENTA_END_ROD;
	static {
		OAK_END_ROD = block(MoreandmoreendrodsModBlocks.OAK_END_ROD);
		CHERRY_END_ROD = block(MoreandmoreendrodsModBlocks.CHERRY_END_ROD);
		BIRCH_END_ROD = block(MoreandmoreendrodsModBlocks.BIRCH_END_ROD);
		SPRUCE_END_ROD = block(MoreandmoreendrodsModBlocks.SPRUCE_END_ROD);
		STONE_END_ROD = block(MoreandmoreendrodsModBlocks.STONE_END_ROD, new Item.Properties().fireResistant());
		IRON_END_ROD = block(MoreandmoreendrodsModBlocks.IRON_END_ROD, new Item.Properties().fireResistant());
		COPPER_END_ROD = block(MoreandmoreendrodsModBlocks.COPPER_END_ROD, new Item.Properties().fireResistant());
		GLOWSTONE_END_ROD = block(MoreandmoreendrodsModBlocks.GLOWSTONE_END_ROD);
		EMERALD_END_ROD = block(MoreandmoreendrodsModBlocks.EMERALD_END_ROD);
		DIAMOND_END_ROD = block(MoreandmoreendrodsModBlocks.DIAMOND_END_ROD);
		NETHERITE_END_ROD = block(MoreandmoreendrodsModBlocks.NETHERITE_END_ROD);
		CRIMSON_END_ROD = block(MoreandmoreendrodsModBlocks.CRIMSON_END_ROD);
		WARPED_END_ROD = block(MoreandmoreendrodsModBlocks.WARPED_END_ROD);
		EXPOSED_COPPER_END_ROD = block(MoreandmoreendrodsModBlocks.EXPOSED_COPPER_END_ROD);
		WEATHERED_COPPER_END_ROD = block(MoreandmoreendrodsModBlocks.WEATHERED_COPPER_END_ROD);
		OXIDIZED_COPPER_END_ROD = block(MoreandmoreendrodsModBlocks.OXIDIZED_COPPER_END_ROD);
		WAXED_COPPER_END_ROD = block(MoreandmoreendrodsModBlocks.WAXED_COPPER_END_ROD, new Item.Properties().fireResistant());
		WAXED_EXPOSED_COPPER_END_ROD = block(MoreandmoreendrodsModBlocks.WAXED_EXPOSED_COPPER_END_ROD);
		WAXED_WEATHERED_COPPER_END_ROD = block(MoreandmoreendrodsModBlocks.WAXED_WEATHERED_COPPER_END_ROD);
		JUNGLE_END_ROD = block(MoreandmoreendrodsModBlocks.JUNGLE_END_ROD);
		ACACIA_END_ROD = block(MoreandmoreendrodsModBlocks.ACACIA_END_ROD);
		DARK_OAK_END_ROD = block(MoreandmoreendrodsModBlocks.DARK_OAK_END_ROD);
		MANGROVE_END_ROD = block(MoreandmoreendrodsModBlocks.MANGROVE_END_ROD);
		PRISMARINE_END_ROD = block(MoreandmoreendrodsModBlocks.PRISMARINE_END_ROD);
		GOLDEN_END_ROD = block(MoreandmoreendrodsModBlocks.GOLDEN_END_ROD);
		SHULKER_END_ROD = block(MoreandmoreendrodsModBlocks.SHULKER_END_ROD);
		PINK_END_ROD = block(MoreandmoreendrodsModBlocks.PINK_END_ROD);
		BLUE_END_ROD = block(MoreandmoreendrodsModBlocks.BLUE_END_ROD);
		LIGHT_BLUE_END_ROD = block(MoreandmoreendrodsModBlocks.LIGHT_BLUE_END_ROD);
		PURPLE_END_ROD = block(MoreandmoreendrodsModBlocks.PURPLE_END_ROD);
		YELLOW_END_ROD = block(MoreandmoreendrodsModBlocks.YELLOW_END_ROD);
		GRAY_END_ROD = block(MoreandmoreendrodsModBlocks.GRAY_END_ROD);
		LIGHT_GRAY_END_ROD = block(MoreandmoreendrodsModBlocks.LIGHT_GRAY_END_ROD);
		BLACK_END_ROD = block(MoreandmoreendrodsModBlocks.BLACK_END_ROD);
		ORANGE_END_ROD = block(MoreandmoreendrodsModBlocks.ORANGE_END_ROD);
		RED_END_ROD = block(MoreandmoreendrodsModBlocks.RED_END_ROD);
		CYAN_END_ROD = block(MoreandmoreendrodsModBlocks.CYAN_END_ROD);
		GREEN_END_ROD = block(MoreandmoreendrodsModBlocks.GREEN_END_ROD);
		LIME_END_ROD = block(MoreandmoreendrodsModBlocks.LIME_END_ROD);
		AMETHYST_END_ROD = block(MoreandmoreendrodsModBlocks.AMETHYST_END_ROD);
		BRICK_END_ROD = block(MoreandmoreendrodsModBlocks.BRICK_END_ROD);
		NETHER_BRICK_END_ROD = block(MoreandmoreendrodsModBlocks.NETHER_BRICK_END_ROD);
		MAGENTA_END_ROD = block(MoreandmoreendrodsModBlocks.MAGENTA_END_ROD);
	}

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return block(block, new Item.Properties());
	}

	private static RegistryObject<Item> block(RegistryObject<Block> block, Item.Properties properties) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), properties));
	}
}