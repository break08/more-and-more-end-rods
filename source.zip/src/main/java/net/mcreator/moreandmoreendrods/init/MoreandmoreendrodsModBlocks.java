/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.moreandmoreendrods.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.moreandmoreendrods.block.*;
import net.mcreator.moreandmoreendrods.MoreandmoreendrodsMod;

public class MoreandmoreendrodsModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, MoreandmoreendrodsMod.MODID);
	public static final RegistryObject<Block> OAK_END_ROD;
	public static final RegistryObject<Block> CHERRY_END_ROD;
	public static final RegistryObject<Block> BIRCH_END_ROD;
	public static final RegistryObject<Block> SPRUCE_END_ROD;
	public static final RegistryObject<Block> STONE_END_ROD;
	public static final RegistryObject<Block> IRON_END_ROD;
	public static final RegistryObject<Block> COPPER_END_ROD;
	public static final RegistryObject<Block> GLOWSTONE_END_ROD;
	public static final RegistryObject<Block> EMERALD_END_ROD;
	public static final RegistryObject<Block> DIAMOND_END_ROD;
	public static final RegistryObject<Block> NETHERITE_END_ROD;
	public static final RegistryObject<Block> CRIMSON_END_ROD;
	public static final RegistryObject<Block> WARPED_END_ROD;
	public static final RegistryObject<Block> EXPOSED_COPPER_END_ROD;
	public static final RegistryObject<Block> WEATHERED_COPPER_END_ROD;
	public static final RegistryObject<Block> OXIDIZED_COPPER_END_ROD;
	public static final RegistryObject<Block> WAXED_COPPER_END_ROD;
	public static final RegistryObject<Block> WAXED_EXPOSED_COPPER_END_ROD;
	public static final RegistryObject<Block> WAXED_WEATHERED_COPPER_END_ROD;
	public static final RegistryObject<Block> JUNGLE_END_ROD;
	public static final RegistryObject<Block> ACACIA_END_ROD;
	public static final RegistryObject<Block> DARK_OAK_END_ROD;
	public static final RegistryObject<Block> MANGROVE_END_ROD;
	public static final RegistryObject<Block> PRISMARINE_END_ROD;
	public static final RegistryObject<Block> GOLDEN_END_ROD;
	public static final RegistryObject<Block> SHULKER_END_ROD;
	public static final RegistryObject<Block> PINK_END_ROD;
	public static final RegistryObject<Block> BLUE_END_ROD;
	public static final RegistryObject<Block> LIGHT_BLUE_END_ROD;
	public static final RegistryObject<Block> PURPLE_END_ROD;
	public static final RegistryObject<Block> YELLOW_END_ROD;
	public static final RegistryObject<Block> GRAY_END_ROD;
	public static final RegistryObject<Block> LIGHT_GRAY_END_ROD;
	public static final RegistryObject<Block> BLACK_END_ROD;
	public static final RegistryObject<Block> ORANGE_END_ROD;
	public static final RegistryObject<Block> RED_END_ROD;
	public static final RegistryObject<Block> CYAN_END_ROD;
	public static final RegistryObject<Block> GREEN_END_ROD;
	public static final RegistryObject<Block> LIME_END_ROD;
	public static final RegistryObject<Block> AMETHYST_END_ROD;
	public static final RegistryObject<Block> BRICK_END_ROD;
	public static final RegistryObject<Block> NETHER_BRICK_END_ROD;
	public static final RegistryObject<Block> MAGENTA_END_ROD;
	static {
		OAK_END_ROD = REGISTRY.register("oak_end_rod", OakEndRodBlock::new);
		CHERRY_END_ROD = REGISTRY.register("cherry_end_rod", CherryEndRodBlock::new);
		BIRCH_END_ROD = REGISTRY.register("birch_end_rod", BirchEndRodBlock::new);
		SPRUCE_END_ROD = REGISTRY.register("spruce_end_rod", SpruceEndRodBlock::new);
		STONE_END_ROD = REGISTRY.register("stone_end_rod", StoneEndRodBlock::new);
		IRON_END_ROD = REGISTRY.register("iron_end_rod", IronEndRodBlock::new);
		COPPER_END_ROD = REGISTRY.register("copper_end_rod", CopperEndRodBlock::new);
		GLOWSTONE_END_ROD = REGISTRY.register("glowstone_end_rod", GlowstoneEndRodBlock::new);
		EMERALD_END_ROD = REGISTRY.register("emerald_end_rod", EmeraldEndRodBlock::new);
		DIAMOND_END_ROD = REGISTRY.register("diamond_end_rod", DiamondEndRodBlock::new);
		NETHERITE_END_ROD = REGISTRY.register("netherite_end_rod", NetheriteEndRodBlock::new);
		CRIMSON_END_ROD = REGISTRY.register("crimson_end_rod", CrimsonEndRodBlock::new);
		WARPED_END_ROD = REGISTRY.register("warped_end_rod", WarpedEndRodBlock::new);
		EXPOSED_COPPER_END_ROD = REGISTRY.register("exposed_copper_end_rod", ExposedCopperEndRodBlock::new);
		WEATHERED_COPPER_END_ROD = REGISTRY.register("weathered_copper_end_rod", WeatheredCopperEndRodBlock::new);
		OXIDIZED_COPPER_END_ROD = REGISTRY.register("oxidized_copper_end_rod", OxidizedCopperEndRodBlock::new);
		WAXED_COPPER_END_ROD = REGISTRY.register("waxed_copper_end_rod", WaxedCopperEndRodBlock::new);
		WAXED_EXPOSED_COPPER_END_ROD = REGISTRY.register("waxed_exposed_copper_end_rod", WaxedExposedCopperEndRodBlock::new);
		WAXED_WEATHERED_COPPER_END_ROD = REGISTRY.register("waxed_weathered_copper_end_rod", WaxedWeatheredCopperEndRodBlock::new);
		JUNGLE_END_ROD = REGISTRY.register("jungle_end_rod", JungleEndRodBlock::new);
		ACACIA_END_ROD = REGISTRY.register("acacia_end_rod", AcaciaEndRodBlock::new);
		DARK_OAK_END_ROD = REGISTRY.register("dark_oak_end_rod", DarkOakEndRodBlock::new);
		MANGROVE_END_ROD = REGISTRY.register("mangrove_end_rod", MangroveEndRodBlock::new);
		PRISMARINE_END_ROD = REGISTRY.register("prismarine_end_rod", PrismarineEndRodBlock::new);
		GOLDEN_END_ROD = REGISTRY.register("golden_end_rod", GoldenEndRodBlock::new);
		SHULKER_END_ROD = REGISTRY.register("shulker_end_rod", ShulkerEndRodBlock::new);
		PINK_END_ROD = REGISTRY.register("pink_end_rod", PinkEndRodBlock::new);
		BLUE_END_ROD = REGISTRY.register("blue_end_rod", BlueEndRodBlock::new);
		LIGHT_BLUE_END_ROD = REGISTRY.register("light_blue_end_rod", LightBlueEndRodBlock::new);
		PURPLE_END_ROD = REGISTRY.register("purple_end_rod", PurpleEndRodBlock::new);
		YELLOW_END_ROD = REGISTRY.register("yellow_end_rod", YellowEndRodBlock::new);
		GRAY_END_ROD = REGISTRY.register("gray_end_rod", GrayEndRodBlock::new);
		LIGHT_GRAY_END_ROD = REGISTRY.register("light_gray_end_rod", LightGrayEndRodBlock::new);
		BLACK_END_ROD = REGISTRY.register("black_end_rod", BlackEndRodBlock::new);
		ORANGE_END_ROD = REGISTRY.register("orange_end_rod", OrangeEndRodBlock::new);
		RED_END_ROD = REGISTRY.register("red_end_rod", RedEndRodBlock::new);
		CYAN_END_ROD = REGISTRY.register("cyan_end_rod", CyanEndRodBlock::new);
		GREEN_END_ROD = REGISTRY.register("green_end_rod", GreenEndRodBlock::new);
		LIME_END_ROD = REGISTRY.register("lime_end_rod", LimeEndRodBlock::new);
		AMETHYST_END_ROD = REGISTRY.register("amethyst_end_rod", AmethystEndRodBlock::new);
		BRICK_END_ROD = REGISTRY.register("brick_end_rod", BrickEndRodBlock::new);
		NETHER_BRICK_END_ROD = REGISTRY.register("nether_brick_end_rod", NetherBrickEndRodBlock::new);
		MAGENTA_END_ROD = REGISTRY.register("magenta_end_rod", MagentaEndRodBlock::new);
	}
	// Start of user code block custom blocks
	// End of user code block custom blocks
}